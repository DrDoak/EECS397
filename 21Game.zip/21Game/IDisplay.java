interface IDisplay {

    // update the sum field 
    void sumDisplay(int s);
    
    //update the skip field
    void skipsDisplay(int sk);

    // update the message field 
    void msgDisplay(String s); 
}
